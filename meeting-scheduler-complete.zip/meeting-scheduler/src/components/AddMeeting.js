import React, { Component } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import moment from 'moment';

class AddMeeting extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currDateValue: this.props.currDate,
            start_time: this.props.currDate,
            end_time: this.props.currDate,
            listMeeting: [],
            search: false,
            availabilty: undefined,
        }
    };

    parseTime(time) {
        return parseInt(time.split(':')[0]) * 100 + parseInt(time.split(':')[0]);
    }

    compare(oldStart, oldEnd, reqStart, reqEnd) {
        let oldS = this.parseTime(oldStart);
        let oldE = this.parseTime(oldEnd);
        let newS = this.parseTime(reqStart);
        let newE = this.parseTime(reqEnd);
        return Math.max(oldS, newS) <= Math.min(oldE, newE);
    }

    checkForAvailabilty = () => {
        console.log(this.state.listMeeting);
        let start_time = moment(this.state.start_time).format('HH:mm');
        let end_time = moment(this.state.end_time).format('HH:mm');
        let listMeeting = this.state.listMeeting;
        let overlapped = listMeeting.filter((item) => {
            return this.compare(item.start_time, item.end_time, start_time, end_time);
        });
        this.setState({
            search: true,
            availabilty: !overlapped.length,
        })

    }
    getMeetings = (currDate) => {
        const date = currDate.format("DD/MM/YYYY");
        const proxyurl = "https://cors-anywhere.herokuapp.com/";
        let url = `http://fathomless-shelf-5846.herokuapp.com/api/schedule?date="${date}"`;
        console.log(url);
        let this_ = this;
        fetch(proxyurl + url)
            .then(res => res.json())
            .then((data) => {
                this.setState({
                    listMeeting: data,
                })
                this_.checkForAvailabilty();
            })
            .catch(console.log)
    };

    handleDate = (e) => {
        this.setState({
            currDateValue: e,
        });
    };
    handleStartTime = (e) => {
        this.setState({
            start_time: e,
        })
    }
    handleEndTime = (e) => {
        this.setState({
            end_time: e,
        })
    }
    handleSubmit = () => {
        let momentDate = moment(this.state.currDateValue);
        this.getMeetings(momentDate);

    }

    render() {
        return (
            <div className="meeting-form">
                <div className="date-picker m-2">
                    Date:
                    <DatePicker
                        showPopperArrow={false}
                        selected={this.state.currDateValue}
                        name="date"
                        onChange={this.handleDate}
                    />
                </div>
                <div className="m-2">
                    Start Time:
                    <DatePicker
                        className="time-picker"
                        selected={this.state.start_time}
                        onChange={this.handleStartTime}
                        showTimeSelect
                        showTimeSelectOnly
                        timeIntervals={15}
                        timeCaption="Time"
                        dateFormat="h:mm aa"
                    />
                </div>
                <div className="m-2">
                    End Time:
                    <DatePicker
                        className="time-picker"
                        selected={this.state.end_time}
                        onChange={this.handleEndTime}
                        showTimeSelect
                        showTimeSelectOnly
                        timeIntervals={15}
                        timeCaption="Time"
                        dateFormat="h:mm aa"
                    />
                </div>
                <div>
                    Discription:
                    <textarea
                        name="description"
                        placeholder='Description'
                    />
                </div>
                <button className="btn btn-primary" onClick={this.handleSubmit}> Submit</button>
                <div className="availabilty">
                    {
                        this.state.search ?
                            [
                                (this.state.availabilty) ?
                                    (
                                        <div className="alert alert-success" role="alert">
                                            Slot is Available!
                                        </div>
                                    )
                                    :
                                    (
                                        <div class="alert alert-danger" role="alert">
                                            Sorry, Slot is not available!
                                        </div>
                                    )

                            ]
                            :
                            null
                    }
                </div>
            </div>
        )
    }
}

export default AddMeeting;