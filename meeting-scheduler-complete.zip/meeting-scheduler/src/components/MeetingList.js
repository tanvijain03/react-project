import React, { Component } from 'react';
import Moment from 'react-moment';
import 'moment-timezone';
import moment from 'moment';
import { ListGroup, Row, Col } from 'react-bootstrap';
import AddMeeting from './AddMeeting';

class MeetingList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            listOfMeeting: [],
            date: moment(Date.now()),
            isAddMeeting: false,
        }
    };
    getMeetings = (currDate) => {
        const date = currDate.format("DD/MM/YYYY");
        const proxyurl = "https://cors-anywhere.herokuapp.com/";
        let url = `http://fathomless-shelf-5846.herokuapp.com/api/schedule?date="${date}"`;
        fetch(proxyurl + url)
            .then(res => res.json())
            .then((data) => {
                this.setState({ listOfMeeting: data })
            })
            .catch(console.log)
    };

    decreaseDate = () => {
        let currDate = moment(this.state.date);
        currDate.subtract(1, 'day');
        this.setState({ date: currDate });
        this.getMeetings(currDate);
    };
    increaseDate = () => {
        let currDate = moment(this.state.date);
        currDate.add(1, 'day');
        this.setState({ date: currDate });
        this.getMeetings(currDate);
    };



    formatList = (listOfMeeting) => {
        if (listOfMeeting.length === 0) {
            return <Row className="empty-list">Empty</Row>
        }
        return listOfMeeting.map((item, index) => {
            return (
                <ListGroup.Item key={index}>
                    <Row>
                        <Col sm>{item.start_time} - {item.end_time}</Col>
                        <Col sm>{item.description}</Col>
                    </Row>
                </ListGroup.Item>

            )
        })
    }

    handleMeeting = () => {
        this.setState({
            isAddMeeting: !this.state.isAddMeeting,
        })
    }

    componentDidMount() {
        this.getMeetings(this.state.date);
    }

    render() {
        let { date, listOfMeeting } = this.state;
        const formatedList = this.formatList(listOfMeeting);
        return (
            <div className="meetings">
                {
                    !this.state.isAddMeeting ?
                        <div className="meeting-list">
                            <div className="select-date">
                                <button onClick={this.decreaseDate.bind(this)}><i class="arrow left"></i></button>
                                <Moment format="D MMM YYYY">{date}</Moment>
                                <button onClick={this.increaseDate.bind(this)}><i class="arrow right"></i></button>
                            </div>
                            <ListGroup className="meeting-table">
                                {formatedList}
                            </ListGroup>

                        </div>
                        :
                        <div className="add-meeting">
                            <AddMeeting currDate={this.state.date.toDate()} />
                        </div>
                }
                <div>
                    <button className="btn btn-info m-5" onClick={this.handleMeeting}>{this.state.isAddMeeting ? "List Meeting" : "Add Meeting"}</button>
                </div>
            </div>
        );
    }
}

export default MeetingList;