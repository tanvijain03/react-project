import React, { Component } from 'react';
import './App.css';
import MeetingList from './components/MeetingList';
import Form from "./form";

class App extends Component {
  state = {
    fields: {}
  };


  onChange = fields => {
    this.setStage({ fields });
  };

  render() {
    return (
      <div className="meeting-scheduler">
        <MeetingList />
        <Form onChange={fields => this.onSubmit(fields)} />
        <p>
          {JSON.stringify(this.state.fields, null, 2)}
        </p>
      </div>
    );
  }
}

export default App;
