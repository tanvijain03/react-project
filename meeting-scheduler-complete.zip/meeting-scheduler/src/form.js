import React, { Component } from 'react';

class Form extends Component {
    state = {
        meetingDate: '',
        startTime: '',
        endTime: '',
        description: ''
    }

    change = e => {
        this.setState({
            [e.target.name]: e.target.value
        });
    };

    onSubmit = e => {
        e.preventDefaut();
        console.log(this.state);
        this.setState({
            meetingDate: '',
            startTime: '',
            endTime: '',
            description: ''
        });
    };

    render() {
        return (
            <form>
                <input
                    name="meetingDate"
                    placeholder='Meeting Date'
                    value={this.state.meetingName}
                    onChange={e => this.change(e)}
                />
                <br />
                <input
                    name="startTime"
                    placeholder='Start Time'
                    value={this.state.startTime}
                    onChange={e => this.change(e)}
                />
                <input
                    name="endTime"
                    placeholder='End Time'
                    value={this.state.endTime}
                    onChange={e => this.change(e)}
                />
                <br />
                <input
                    name="description"
                    placeholder='Description'
                    value={this.state.description}
                    onChange={e => this.change(e)}
                />
                <button onclick={e => this.onsubmit(e)}> save </button>
            </form>
        )
    }

}

export default Form;