import React, { Component } from 'react';
import './App.css';
import MeetingList from './components/MeetingList';

class App extends Component {
  constructor() {
    super();
    this.state = {
      isAddMeeting: false,
    }
  }

  handleMeeting = () => {
    this.setState({
      isAddMeeting: !this.state.isAddMeeting,
    })
  }
  render() {
    return (
      <div className="meeting-scheduler text-center" >
        <MeetingList />
      </div >
    );
  }
}

export default App;
